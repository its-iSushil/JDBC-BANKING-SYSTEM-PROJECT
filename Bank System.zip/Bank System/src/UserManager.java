
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Scanner;

public class UserManager {

    private Connection connection;
    private Scanner scanner;

    public UserManager(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void changePassword(String email) throws SQLException {
        scanner.nextLine();
        System.out.println("Enter old profile password: ");
        if (validateOldPassword(email, scanner.nextLine())) {
            System.out.print("Enter new password: ");
            String newPass = scanner.nextLine();
            System.out.print("Confirm password: ");
            String confirmPass = scanner.nextLine();

            if (newPass.equals(confirmPass)) {
                String q = "update user set password = ? where email = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(q);
                preparedStatement.setString(1, newPass);
                preparedStatement.setString(2, email);
                int status = preparedStatement.executeUpdate();

                if (status > 0) {
                    System.out.println("Password changed successfully!!!");
                }
            } else {
                System.out.println("Password doesn't matches!!!");
            }
        } else {
            System.out.println("Incorrect password(old)");
        }
    }

    private boolean validateOldPassword(String email, String password) throws SQLException {
        String q = "select email from user where email = ? and password = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(q);
        preparedStatement.setString(1, email);
        preparedStatement.setString(2, password);

        ResultSet resultSet = preparedStatement.executeQuery();

        return resultSet.next();
    }
}
