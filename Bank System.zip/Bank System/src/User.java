import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class User {
    private final Connection connection;
    private final Scanner scanner;


    public User(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    // Register user
    public void register() {
        scanner.nextLine();
        System.out.print("Enter your full name: ");
        String full_name = scanner.nextLine();
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        System.out.print("Create a password: ");
        String password = scanner.nextLine();

        // Check if user is already exists or not
        if (userExist(email)) {
            System.err.println("\nUser already exists!!!");
            return;
        }

        String q = "insert into user(full_name, email, password) values(?,?,?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(q);
            preparedStatement.setString(1, full_name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, password);

            int affectedRow = preparedStatement.executeUpdate();
            if (affectedRow > 0) {
                System.out.println("\nUser registered successfully!!!");
                System.out.println("Please login into your profile...");
            } else {
                System.err.println("User registration failed!!!");
            }
        } catch (SQLException e) {
            System.err.println("Something went wrong!!!");
        }
    } // End of Registration part

    // Login
    public String logIn() {
        scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (userExist(email)) {
            String q = "select * from user where email = ? and password = ?";

            try {
                PreparedStatement preparedStatement = connection.prepareStatement(q);
                preparedStatement.setString(1, email);
                preparedStatement.setString(2, password);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    System.out.println("Login Successfully!!!");
                    return email;
                } else {
                    System.out.println("Incorrect email/password!!!");
                    return null;
                }

            } catch (SQLException e) {
                System.err.println(e);
            }
        } else {
            System.out.println("User doesn't exist for this email!!!");
        }

        return null;
    } // end of login

    // Register helper function
    private boolean userExist(String email) {
        String q = "select email from user where email = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(q);
            preparedStatement.setString(1, email);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next())
                return true;
        } catch (SQLException e) {
            System.err.println("Something went wrong!!!");
        }

        return false;
    }

    public String getCustomerName(String email) throws SQLException {
        String q = "select full_name from user where email=?";
        PreparedStatement preparedStatement = connection.prepareStatement(q);
        preparedStatement.setString(1, email);
        ResultSet resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
            return resultSet.getString("full_name");
        }
        return null;
    }
}
