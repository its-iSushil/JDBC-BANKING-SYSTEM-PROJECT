import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    private static String forName = "com.mysql.cj.jdbc.Driver";
    private static String url = "jdbc:mysql://localhost:3306/BankingSystem"; // Change with your db_name
    private static String username = "root"; // Change with your root name
    private static String password = "admin"; // Change with your password


    public static void main(String[] args) {
        // TODO Auto-generated method stub

        try {
            Class.forName(forName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            Scanner scanner = new Scanner(System.in);

            User user = new User(connection, scanner);
            Accounts accounts = new Accounts(connection, scanner);
            AccountManager accountManager = new AccountManager(connection, scanner);
            UserManager userManager = new UserManager(connection, scanner);

            String email;
            long accountNumber;
            boolean flag = false;
            outermost:
            while (!flag) {
                System.out.println("----------------------------------------------------");
                System.out.println("           Welcome to JDBC Banking System           ");
                System.out.println("----------------------------------------------------");
                System.out.println("1. Login to my account");
                System.out.println("2. New user?");
                System.out.println("3. Exit");
                System.out.print("\nReply: ");
                int ch = scanner.nextInt();

                if (ch == 1) {
                    email = user.logIn();
                    if (email != null) {
                        System.out.println("\nWelcome, " + user.getCustomerName(email));
                        if (!accounts.isUserExist(email)) {
                            System.out.println("1. Create New Bank Account");
                            System.out.println("2. Change Profile Password");
                            System.out.println("3. Logout");
                            System.out.print("\nReply: ");

                            int ch2 = scanner.nextInt();
                            if (ch2 == 1) {
                                accountNumber = accounts.createAccount();
                                if (accountNumber == 0)
                                    System.out.println("Something went wrong!!!");
                                else
                                    System.out.println("Account number: " + accountNumber);
                            } else if (ch2 == 2) {
                                userManager.changePassword(email);
                            } else if (ch2 == 3) {
                                System.out.println("\n--------------------------------");
                                System.out.println("Thank you for banking with us!!!");
                                System.out.println("--------------------------------");
                                break outermost;
                            }
                        }
                        ch = 0;
                        accountNumber = accounts.getAccNo(email);

                        outer:
                        while (true) {
                            System.out.println("\n1. Deposit Money");
                            System.out.println("2. Withdraw Money");
                            System.out.println("3. Transfer Money");
                            System.out.println("4. Check Balance");
                            System.out.println("\nMore\n5. Get Account Number\n6. Change account Pin\n7. Close account\n8. Logout");
                            System.out.println("\nProfile settings\n9. Change profile password");
                            System.out.print("\nReply: ");

                            switch (scanner.nextInt()) {
                                case 1:
                                    accountManager.deposit(accountNumber);
                                    break;
                                case 2:
                                    accountManager.withdraw(accountNumber);
                                    break;
                                case 3:
                                    accountManager.transfer(accountNumber);
                                    break;
                                case 4:
                                    scanner.nextLine();
                                    long balance = accountManager.checkBalance(accountNumber);
                                    System.out.println("Available balance: " + balance);
                                    break;
                                case 5:
                                    System.out.println("Account number: " + accounts.getAccNo(email));
                                    break;
                                case 6:
                                    accounts.changePin(accountNumber);
                                    break;
                                case 7:
                                    if (accountManager.closeAccount(accountNumber) != 0) {
                                        break outer;
                                    }
                                    break;
                                case 8:
                                    break outer;
                                case 9:
                                    userManager.changePassword(email);
                                    break;
                            }
                        }
                    }
                } else if (ch == 2) {
                    user.register();
                } else {
                    flag = true;
                    System.out.println("\n--------------------------------");
                    System.out.println("Thank you for banking with us!!!");
                    System.out.println("--------------------------------");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (InputMismatchException e) {
            System.out.println("Invalid choice");
        }
    }
}
