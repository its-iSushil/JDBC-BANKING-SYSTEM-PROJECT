import java.math.BigDecimal;
import java.sql.*;
import java.util.Scanner;

public class Accounts {
    private final Connection connection;
    private final Scanner scanner;
    boolean isPinSet = false;

    public Accounts(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public long createAccount() throws SQLException {
        scanner.nextLine();
        System.out.print("Enter you name: ");
        String full_name = scanner.nextLine();
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();

        if (!isUserExist(email)) {

            while (!isPinSet) {

                System.out.print("Create a 4 digit security pin: ");
                String pin = scanner.nextLine();

                if (validatePin(pin)) {
                    String q = "insert into accounts values(?,?,?,?,?)";
                    PreparedStatement preparedStatement = connection.prepareStatement(q);
                    long acno = setAccNo();
                    preparedStatement.setLong(1, acno);
                    preparedStatement.setString(2, full_name);
                    preparedStatement.setString(3, email);
                    preparedStatement.setBigDecimal(4, BigDecimal.valueOf(500.00));
                    preparedStatement.setString(5, pin);

                    int affectedRow = preparedStatement.executeUpdate();
                    if (affectedRow > 0) {
                        isPinSet = true;
                        System.out.println("\n-------------------------------");
                        System.out.println("Account created successfully!!!");
                        System.out.println("-------------------------------");
                        return acno;
                    } else {
                        System.err.println("\nSomething went wrong!!!");
                    }

                } else {
                    System.out.println("\nEnter 4 digit pin!!!\n");
                }
            }
        } else {
            System.err.println("Account already exist!!!");
        }
        return 0;
    }

    public long getAccNo(String email) throws SQLException {

        String q = "select account_number from accounts where email = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(q);
        preparedStatement.setString(1, email);

        ResultSet resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
            return resultSet.getLong("account_number");
        } else {
            System.out.println("Account does not exist!!!");
        }

        return 123456789;
    }

    public void changePin(long accountNumber) throws SQLException {
        isPinSet = false;

        while (!isPinSet) {
            System.out.print("Enter old pin: ");
            String oldPin = scanner.nextLine();

            if (validateOldPin(oldPin)) {
                System.out.print("\nEnter new pin: ");
                String newPin = scanner.nextLine();
                System.out.print("\nConfirm new pin: ");
                String confirmPin = scanner.nextLine();

                if (newPin.equals(confirmPin)) {
                    String q = "update accounts set security_pin = ? where security_pin=? and account_number = ?";
                    PreparedStatement preparedStatement = connection.prepareStatement(q);
                    preparedStatement.setString(1, newPin);
                    preparedStatement.setString(2, oldPin);
                    preparedStatement.setLong(3, accountNumber);
                    int status = preparedStatement.executeUpdate();

                    if (status > 0) {
                        isPinSet = true;
                        System.out.println("\nPassword changed successfully!!!");
                    } else {
                        System.out.println("Something went wrong!!!");
                    }
                } else {
                    System.out.println("\nPassword doesn't match!!!");
                }
            } else {
                System.out.println("\nIncorrect password!!!\n");
            }
        }

    }

    protected boolean isUserExist(String email) throws SQLException {

        String q = "Select email from Accounts where email = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(q);
        preparedStatement.setString(1, email);

        ResultSet resultSet = preparedStatement.executeQuery();
        return resultSet.next();
    }

    private boolean validatePin(String pin) {
        return pin.length() == 4 && pin.matches("\\d{4}");
    }

    private long setAccNo() {
        try {
            Statement statement = connection.createStatement();
            String q = "select account_number from accounts order by account_number desc limit 1";
            ResultSet resultSet = statement.executeQuery(q);

            if (resultSet.next()) {
                long acc_no = resultSet.getLong("account_number");
                return acc_no + 1;
            } else {
                return 10001000;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    protected boolean validateOldPin(String pin) throws SQLException {
        String q = "select security_pin from accounts where security_pin = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(q);
        preparedStatement.setString(1, pin);
        ResultSet resultSet = preparedStatement.executeQuery();
        return resultSet.next();
    }
}
