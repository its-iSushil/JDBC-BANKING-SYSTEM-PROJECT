import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AccountManager {
    private Connection connection;
    private Scanner scanner;
    public static boolean isAccountDeleted = false;

    public AccountManager(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void deposit(long accountNumber) throws SQLException {
        connection.setAutoCommit(false);
        System.out.print("Enter amount: ");
        long amount = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Enter pin: ");
        String pin = scanner.nextLine();

        if (validatePin(accountNumber, pin)) {
            String q = "update accounts set balance = balance+? where account_number = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(q);
            preparedStatement.setLong(1, amount);
            preparedStatement.setLong(2, accountNumber);
            int status = preparedStatement.executeUpdate();

            if (status > 0) {
                System.out.println(amount + " deposited successfully!!!");
                connection.commit();
                connection.setAutoCommit(true);
            } else {
                System.out.println("Transaction failed!!!");
                connection.rollback();
                connection.setAutoCommit(true);
            }

        } else {
            System.out.println("Incorrect pin!!!");
        }
    }

    public void withdraw(long accountNumber) throws SQLException {
        connection.setAutoCommit(false);
        System.out.print("Enter amount: ");
        long amount = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Enter pin: ");
        String pin = scanner.nextLine();

        if (validatePin(accountNumber, pin)) {
            String q = "select balance from accounts where account_number=?";
            PreparedStatement preparedStatement = connection.prepareStatement(q);
            preparedStatement.setLong(1, accountNumber);
            ResultSet resultSet = preparedStatement.executeQuery();
            long balance = 0;
            if (resultSet.next()) {
                balance = resultSet.getLong("balance");
            }

            if (amount <= balance) {
                String query = "update accounts set balance = balance-? where account_number = ?";
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setLong(1, amount);
                preparedStatement.setLong(2, accountNumber);
                int status = preparedStatement.executeUpdate();

                if (status > 0) {
                    System.out.println(amount + " withdraw successfully!!!");
                    connection.commit();
                    connection.setAutoCommit(true);
                } else {
                    System.out.println("Transaction failed!!!");
                    connection.rollback();
                    connection.setAutoCommit(true);
                }
            } else {
                System.out.println("Insufficient balance!!!");
            }
        } else {
            System.out.println("Incorrect pin!!!");
        }
    }

    public long checkBalance(long acountNumber) throws SQLException {
        System.out.print("Enter pin: ");
        String pin = scanner.nextLine();

        if (validatePin(acountNumber, pin)) {
            String q = "select balance from accounts where account_number=?";
            PreparedStatement preparedStatement = connection.prepareStatement(q);
            preparedStatement.setLong(1, acountNumber);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                long balance = resultSet.getLong("balance");
                return balance;
            }
        } else {
            System.out.println("Incorrect pin!!!");
        }
        return 0;
    }

    public long checkBalance(long acountNumber, String delete) throws SQLException {
        String q = "select balance from accounts where account_number=?";
        PreparedStatement preparedStatement = connection.prepareStatement(q);
        preparedStatement.setLong(1, acountNumber);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            long balance = resultSet.getLong("balance");
            return balance;
        }

        return 0;
    }

    protected boolean isAccountExist(long accountNumber) throws SQLException {
        String q = "Select account_number from accounts where account_number = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(q);
        preparedStatement.setLong(1, accountNumber);

        ResultSet resultSet = preparedStatement.executeQuery();
        return resultSet.next();
    }

    protected boolean validatePin(long accountNumber, String pin) throws SQLException {
        String q = "select security_pin from accounts where account_number = ? and security_pin = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(q);
        preparedStatement.setLong(1, accountNumber);
        preparedStatement.setString(2, pin);
        ResultSet resultSet = preparedStatement.executeQuery();
        return resultSet.next();
    }

    public void transfer(long accountNumber) throws SQLException {
        System.out.print("Enter receiver's account number: ");
        long receiver_ac_no = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Enter amount: ");
        long amount = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Enter pin: ");
        String pin = scanner.nextLine();

        if (isAccountExist(receiver_ac_no)) {
            if (validatePin(accountNumber, pin)) {
                String q = "select balance from accounts where account_number=?";
                PreparedStatement preparedStatement = connection.prepareStatement(q);
                preparedStatement.setLong(1, accountNumber);
                ResultSet resultSet = preparedStatement.executeQuery();
                long balance = 0;
                if (resultSet.next()) {
                    balance = resultSet.getLong("balance");
                }

                if (amount <= balance) {
                    String query1 = "update accounts set balance = balance+? where account_number = ?";
                    preparedStatement = connection.prepareStatement(query1);
                    preparedStatement.setLong(1, amount);
                    preparedStatement.setLong(2, receiver_ac_no);
                    int status1 = preparedStatement.executeUpdate();

                    String query = "update accounts set balance = balance-? where account_number = ?";
                    preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setLong(1, amount);
                    preparedStatement.setLong(2, accountNumber);
                    int status2 = preparedStatement.executeUpdate();

                    if (status2 > 0 && status1 > 0) {
                        System.out.println(amount + " transferred successfully!!!");
                    } else {
                        System.out.println("Transaction failed!!!");
                    }
                } else {
                    System.out.println("Insufficient balance!!!");
                }
            } else {
                System.out.println("Incorrect pin");
            }
        } else {
            System.out.println("Incorrect/Account doesn't exist!!!");
        }
    }

    public int closeAccount(long accountNumber) {
        scanner.nextLine();
        System.out.println("ARE YOU SURE? ONCE YOU CLOSE THE ACCOUNT THIS ACTION CAN'T BE UNDONE!!!");
        System.out.print("\n1. Yes, close the account!\n2. Cancel\n\nReply: ");
        try {
            switch (scanner.nextInt()) {
                case 1:
                    scanner.nextLine();
                    if (checkBalance(accountNumber, "delete") == 0) {
                        System.out.print("Enter account pin: ");
                        String pin = scanner.nextLine();
                        boolean flag = validatePin(accountNumber, pin);
                        if (flag) {
                            String q = "delete from accounts where account_number = ?";
                            PreparedStatement preparedStatement = connection.prepareStatement(q);
                            preparedStatement.setLong(1, accountNumber);

                            int status = preparedStatement.executeUpdate();
                            if (status > 0) {
                                isAccountDeleted = true;
                                System.out.println("\n-----------------------------");
                                System.out.println("ACCOUNT PERMANENTLY CLOSED!!!");
                                System.out.println("-----------------------------");
                                return 1;
                            } else {
                                System.out.println("Something went wrong!!!");
                            }
                        } else {
                            System.out.println("Incorrect pin!!!");
                        }
                    } else {
                        System.out.println("THIS ACCOUNT CAN'T BE CLOSE\nIn order to close your account you must withdraw all the money");
                        return 0;
                    }
                    break;
                case 2:
                    return 0;
                default:
                    System.out.println("Invalid option!!!");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid option");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }
}
